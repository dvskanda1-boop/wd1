# Shravya Services website recreation

This project restores the original client-side React components exposed by the supplied website preview. It preserves the reference's section structure, content, styling, images, responsive layout, and call/WhatsApp/directions interactions.

## Run locally

```sh
pnpm install
pnpm dev
```

The original backend source was not exposed. The recreated frontend therefore keeps the original review and enquiry API calls but runs without the original services: reviews fall back to the same authorization-pending state, and a form submission opens WhatsApp while warning if the enquiry could not be saved. The original `/admin` interface is included, but it cannot retrieve or update enquiries without the backend and its admin key.

The site is running in the Manus project Preview. It has not been published.
