import { ExternalLink, MapPin, Phone } from "lucide-react";
import Logo from "@/components/Logo";
import { BUSINESS, HOURS, SERVICES, telLink, waLink } from "@/constants/business";
import { WhatsAppIcon } from "@/components/Icons";

const NAV = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Why Us", href: "#why-us" },
  { label: "Reviews", href: "#reviews" },
  { label: "Gallery", href: "#gallery" },
  { label: "Contact", href: "#contact" },
];

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-white/10 bg-brand-ink" data-testid="footer">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 md:grid-cols-2 lg:grid-cols-4 lg:px-8">
        <div>
          <Logo sub="SERVICES" />
          <p className="mt-5 text-sm leading-relaxed text-slate-400">
            Your one stop solution for FASTag, Insurance, GPS Tracking, Taxi and Passport Services in Mangalore.
          </p>
          <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.2em] text-slate-500">Proprietor — {BUSINESS.owner}</p>
        </div>

        <div>
          <p className="font-display text-sm font-bold uppercase tracking-wider text-white">Quick Links</p>
          <ul className="mt-5 space-y-2.5">
            {NAV.map((n) => (
              <li key={n.href}>
                <a href={n.href} data-testid={`footer-link-${n.href.slice(1)}`} className="text-sm text-slate-400 transition-colors hover:text-cyan-300">
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="font-display text-sm font-bold uppercase tracking-wider text-white">Our Services</p>
          <ul className="mt-5 space-y-2.5">
            {SERVICES.map((s) => (
              <li key={s.id}>
                <a href="#services" data-testid={`footer-service-${s.id}`} className="text-sm text-slate-400 transition-colors hover:text-emerald-300">
                  {s.title}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="font-display text-sm font-bold uppercase tracking-wider text-white">Contact</p>
          <ul className="mt-5 space-y-3 text-sm text-slate-400">
            {BUSINESS.phones.map((p, i) => (
              <li key={p}>
                <a href={telLink(p)} data-testid={`footer-phone-${i + 1}`} className="flex items-center gap-2 transition-colors hover:text-cyan-300">
                  <Phone size={14} className="text-cyan-400" /> {p}
                </a>
              </li>
            ))}
            <li>
              <a
                href={waLink("Hello Shravya Services, I would like to enquire about your services.")}
                target="_blank"
                rel="noopener noreferrer"
                data-testid="footer-whatsapp-link"
                className="flex items-center gap-2 transition-colors hover:text-emerald-300"
              >
                <WhatsAppIcon size={14} className="text-emerald-400" /> WhatsApp {BUSINESS.whatsappDisplay}
              </a>
            </li>
            <li className="flex items-start gap-2">
              <MapPin size={14} className="mt-0.5 shrink-0 text-orange-400" /> {BUSINESS.location}
            </li>
            <li className="pt-1">
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-slate-500">Hours</p>
              <p className="mt-1">Mon – Sat: 9:00 AM – 9:00 PM</p>
              <p>Sun: 10:30 AM – 3:00 PM</p>
              <p className="mt-0.5 text-xs text-slate-500">{HOURS.length} days open · walk-ins welcome</p>
            </li>
            <li>
              <a
                href={BUSINESS.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                data-testid="footer-google-reviews-link"
                className="inline-flex items-center gap-1.5 font-semibold text-orange-400 transition-colors hover:text-orange-300"
              >
                <ExternalLink size={13} /> Google Reviews
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10 py-6 text-center">
        <p className="px-4 text-xs text-slate-500" data-testid="footer-copyright">
          © {year} {BUSINESS.name} · {BUSINESS.brand}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
