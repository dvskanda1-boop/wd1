import { motion } from "framer-motion";
import { CheckCircle2, Car, ShieldCheck, Radio, MapPinned, FileText, ArrowUpRight } from "lucide-react";
import { SERVICES, waLink } from "@/constants/business";
import { WhatsAppIcon } from "@/components/Icons";

const ICONS = { fastag: Car, insurance: ShieldCheck, gps: Radio, taxi: MapPinned, passport: FileText };

const cardAnim = (i) => ({
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, amount: 0.12 },
  transition: { duration: 0.55, delay: (i % 3) * 0.08 },
});

function ServiceCard({ service, index }) {
  const Icon = ICONS[service.id] || Car;
  const primary = service.primary;
  return (
    <motion.article
      {...cardAnim(index)}
      data-testid={`service-card-${service.id}`}
      className={`group relative flex flex-col overflow-hidden rounded-3xl border transition-all duration-300 hover:-translate-y-2 ${
        primary
          ? "border-emerald-400/40 bg-gradient-to-b from-emerald-500/15 to-brand-card shadow-glowGreen md:col-span-2"
          : "border-slate-800 bg-brand-card hover:border-cyan-400/40 hover:shadow-glow"
      }`}
    >
      <div className="relative h-44 overflow-hidden sm:h-48">
        <img
          src={service.image}
          alt={`${service.title} illustrative visual`}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-brand-card via-brand-card/20 to-transparent" />
        {primary && (
          <span className="absolute left-4 top-4 rounded-full bg-emerald-500 px-3 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-brand-navy" data-testid="service-fastag-primary-badge">
            {service.tagline}
          </span>
        )}
        <span className={`absolute bottom-4 left-4 rounded-xl border p-2.5 backdrop-blur ${primary ? "border-emerald-400/40 bg-emerald-500/20 text-emerald-300" : "border-white/15 bg-brand-navy/70 text-cyan-300"}`}>
          <Icon size={20} />
        </span>
      </div>

      <div className="flex flex-1 flex-col p-6 sm:p-7">
        <h3 className="font-display text-xl font-bold text-white sm:text-2xl" data-testid={`service-title-${service.id}`}>
          {service.title}
        </h3>
        <p className="mt-3 flex-1 text-sm leading-relaxed text-slate-400" data-testid={`service-description-${service.id}`}>
          {service.description}
        </p>
        <ul className="mt-5 grid grid-cols-1 gap-2 sm:grid-cols-2">
          {service.features.map((f) => (
            <li key={f} className="flex items-center gap-2 text-xs text-slate-300 sm:text-[13px]">
              <CheckCircle2 size={14} className="shrink-0 text-emerald-400" /> {f}
            </li>
          ))}
        </ul>
        <a
          href={waLink(service.msg)}
          target="_blank"
          rel="noopener noreferrer"
          data-testid={`service-enquire-button-${service.id}`}
          className={`mt-7 inline-flex items-center justify-center gap-2.5 rounded-full px-6 py-3 text-sm font-semibold transition-all duration-300 ${
            primary
              ? "bg-emerald-500 text-brand-navy hover:bg-emerald-400"
              : "border border-emerald-400/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/25"
          }`}
        >
          <WhatsAppIcon size={17} /> Enquire Now
          <ArrowUpRight size={15} className="opacity-60" />
        </a>
      </div>
    </motion.article>
  );
}

export default function Services() {
  return (
    <section id="services" className="relative bg-gradient-to-b from-brand-navy via-brand-navy2 to-brand-navy py-24 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.55 }}
          className="mx-auto max-w-2xl text-center"
        >
          <p className="font-mono text-xs uppercase tracking-[0.24em] text-cyan-400">Our Services</p>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl" data-testid="services-heading">
            Five services, <span className="bg-gradient-to-r from-cyan-300 to-emerald-400 bg-clip-text text-transparent">one trusted address</span>
          </h2>
          <p className="mt-4 text-slate-400">Tap Enquire Now to reach us instantly on WhatsApp — we reply during business hours.</p>
        </motion.div>

        <div className="mt-14 grid gap-7 md:grid-cols-2 lg:grid-cols-3" data-testid="services-grid">
          {SERVICES.map((s, i) => (
            <ServiceCard key={s.id} service={s} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
