import { motion } from "framer-motion";
import { ChevronDown, MapPin } from "lucide-react";
import { BUSINESS, IMAGES, openStatus, waLink } from "@/constants/business";

const CHIPS = ["FASTag", "Insurance", "GPS Tracking", "Taxi", "Passport"];

const container = { hidden: {}, show: { transition: { staggerChildren: 0.12 } } };
const item = {
  hidden: { opacity: 0, y: 26 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

export default function Hero() {
  const { open, today } = openStatus();
  return (
    <section id="home" className="relative flex min-h-screen items-center overflow-hidden">
      <img
        src={IMAGES.hero}
        alt="Cars passing through a modern toll plaza"
        className="absolute inset-0 h-full w-full object-cover"
        loading="eager"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-brand-navy via-brand-navy/85 to-brand-navy/40" />
      <div className="absolute inset-0 bg-gradient-to-t from-brand-navy via-transparent to-brand-navy/70" />

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-24 pt-32 sm:px-6 lg:px-8">
        <motion.div variants={container} initial="hidden" animate="show" className="max-w-3xl">
          <motion.div variants={item} className="mb-6 flex flex-wrap items-center gap-3">
            <span className="rounded-full border border-cyan-400/30 bg-cyan-400/10 px-4 py-1.5 font-mono text-[11px] uppercase tracking-[0.2em] text-cyan-300">
              Mangalore · One-Stop Auto Services
            </span>
            <span
              data-testid="hero-open-now-badge"
              className="flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-xs font-medium text-slate-200 backdrop-blur"
            >
              <span className={`relative flex h-2 w-2`}>
                <span className={`absolute inline-flex h-full w-full animate-ping rounded-full ${open ? "bg-emerald-400" : "bg-orange-400"} opacity-75`} />
                <span className={`relative inline-flex h-2 w-2 rounded-full ${open ? "bg-emerald-400" : "bg-orange-400"}`} />
              </span>
              {open ? "Open now" : "Closed now"} · Today {today.open} – {today.close}
            </span>
          </motion.div>

          <motion.h1
            variants={item}
            data-testid="hero-heading"
            className="font-display text-4xl font-extrabold leading-[1.08] tracking-tight text-white sm:text-5xl lg:text-6xl"
          >
            Your Journey,
            <br />
            <span className="bg-gradient-to-r from-cyan-300 via-emerald-300 to-emerald-400 bg-clip-text text-transparent">Our Responsibility.</span>
          </motion.h1>

          <motion.p variants={item} data-testid="hero-subheading" className="mt-6 max-w-xl text-base leading-relaxed text-slate-300 sm:text-lg">
            Your One Stop Solution for FASTag, Insurance, GPS Tracking, Taxi and Passport Services.
          </motion.p>

          <motion.div variants={item} className="mt-9 flex flex-col gap-4 sm:flex-row">
            <a
              href="#services"
              data-testid="hero-explore-services-button"
              className="rounded-full bg-gradient-to-r from-cyan-400 to-emerald-400 px-8 py-4 text-center font-semibold text-brand-navy shadow-glow transition-transform duration-300 hover:scale-[1.03]"
            >
              Explore Our Services
            </a>
            <a
              href="#contact"
              data-testid="hero-contact-us-button"
              className="rounded-full border border-white/25 bg-white/5 px-8 py-4 text-center font-semibold text-white backdrop-blur transition-colors hover:bg-white/15"
            >
              Contact Us
            </a>
          </motion.div>

          <motion.div variants={item} className="mt-10 flex flex-wrap items-center gap-2.5" data-testid="hero-service-chips">
            {CHIPS.map((c) => (
              <a
                key={c}
                href="#services"
                className="rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium text-slate-300 transition-colors hover:border-cyan-400/40 hover:text-cyan-300"
              >
                {c}
              </a>
            ))}
          </motion.div>

          <motion.p variants={item} className="mt-8 flex items-center gap-2 text-sm text-slate-400">
            <MapPin size={15} className="text-orange-400" /> {BUSINESS.location}
          </motion.p>
        </motion.div>
      </div>

      <a
        href="#about"
        data-testid="hero-scroll-indicator"
        aria-label="Scroll to about section"
        className="absolute bottom-6 left-1/2 z-10 -translate-x-1/2 animate-bounce text-slate-400 hover:text-white"
      >
        <ChevronDown size={28} />
      </a>
    </section>
  );
}
