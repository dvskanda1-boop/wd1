import { motion } from "framer-motion";
import { Layers, MessageCircle, MapPin, Headphones, PhoneCall } from "lucide-react";

const REASONS = [
  { icon: Layers, title: "Multiple customer services", text: "FASTag, insurance, GPS, taxi and passport enquiries — all handled at one point.", span: "md:col-span-2" },
  { icon: MessageCircle, title: "Easy communication", text: "Reach us instantly on WhatsApp or with a single tap on a call button.", span: "md:col-span-2" },
  { icon: MapPin, title: "Convenient location", text: "Near the Kia Showroom at Mallikatta, Mangalore — easy to find, easy to visit.", span: "md:col-span-2" },
  { icon: Headphones, title: "Dedicated assistance", text: "A committed team that guides you through every enquiry personally.", span: "md:col-span-3" },
  { icon: PhoneCall, title: "Simple enquiry process", text: "No forms to chase, no queues — just call or message and get answers.", span: "md:col-span-3" },
];

export default function WhyChooseUs() {
  return (
    <section id="why-us" className="py-24 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.55 }}
          className="max-w-2xl"
        >
          <p className="font-mono text-xs uppercase tracking-[0.24em] text-cyan-400">Why Choose Us</p>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl" data-testid="why-heading">
            Service made <span className="text-orange-400">simple</span>, support made personal
          </h2>
        </motion.div>

        <div className="mt-14 grid gap-6 md:grid-cols-6" data-testid="why-grid">
          {REASONS.map((r, i) => (
            <motion.div
              key={r.title}
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
              data-testid={`why-card-${i}`}
              className={`group rounded-3xl border border-slate-800 bg-brand-card p-7 transition-all duration-300 hover:-translate-y-1.5 hover:border-orange-400/40 hover:shadow-[0_0_35px_rgba(249,115,22,0.15)] ${r.span}`}
            >
              <span className="inline-flex rounded-2xl bg-orange-500/12 p-3 text-orange-400 transition-colors group-hover:bg-orange-500/25">
                <r.icon size={22} />
              </span>
              <h3 className="mt-5 font-display text-lg font-bold text-white">{r.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{r.text}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
