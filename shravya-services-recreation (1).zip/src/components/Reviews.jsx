import { useEffect, useState } from "react";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import { motion } from "framer-motion";
import { ExternalLink, Info, MessageSquareQuote, PenLine, RefreshCw } from "lucide-react";
import StarRating from "@/components/StarRating";
import { GoogleGIcon } from "@/components/Icons";
import { BUSINESS } from "@/constants/business";

dayjs.extend(relativeTime);
const API = process.env.REACT_APP_BACKEND_URL;

function ReviewCard({ review }) {
  return (
    <article
      data-testid="review-card"
      className="mb-6 break-inside-avoid rounded-3xl border border-slate-800 bg-brand-card p-6 transition-colors hover:border-cyan-400/30"
    >
      <div className="flex items-center gap-3">
        {review.authorPhoto ? (
          <img src={review.authorPhoto} alt="" className="h-11 w-11 rounded-full border border-white/10 object-cover" />
        ) : (
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-cyan-500/15 font-display text-lg font-bold text-cyan-300">
            {review.author?.charAt(0) || "G"}
          </span>
        )}
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-white" data-testid="review-author">
            {review.author || "Google User"}
          </p>
          <p className="text-xs text-slate-500" title={review.updatedTime ? dayjs(review.updatedTime).format("DD MMM YYYY") : ""}>
            {review.updatedTime ? dayjs(review.updatedTime).fromNow() : ""}
          </p>
        </div>
        <GoogleGIcon size={17} className="ml-auto shrink-0 opacity-80" />
      </div>
      <StarRating rating={review.rating || 0} size={15} className="mt-4" testId="review-star-rating" />
      {review.text && <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-slate-300">{review.text}</p>}
      {review.reply?.text && (
        <div className="mt-4 rounded-xl border-l-2 border-emerald-400/60 bg-emerald-500/8 p-4" data-testid="review-owner-reply">
          <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-emerald-300">
            <MessageSquareQuote size={13} /> Response from the owner
          </p>
          <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-slate-300">{review.reply.text}</p>
        </div>
      )}
    </article>
  );
}

function Buttons({ stack = false }) {
  const reviewUrl = BUSINESS.mapsUrl;
  return (
    <div className={`flex gap-4 ${stack ? "flex-col sm:flex-row" : "flex-col sm:flex-row"}`}>
      <a
        href={reviewUrl}
        target="_blank"
        rel="noopener noreferrer"
        data-testid="reviews-view-all-button"
        className="inline-flex items-center justify-center gap-2 rounded-full border border-white/20 bg-white/5 px-7 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/15"
      >
        <ExternalLink size={16} /> View All Google Reviews
      </a>
      <a
        href={reviewUrl}
        target="_blank"
        rel="noopener noreferrer"
        data-testid="reviews-write-review-button"
        className="inline-flex items-center justify-center gap-2 rounded-full bg-orange-500 px-7 py-3.5 text-sm font-semibold text-white shadow-[0_0_30px_rgba(249,115,22,0.25)] transition-all hover:bg-orange-400 hover:scale-[1.02]"
      >
        <PenLine size={16} /> Write a Google Review
      </a>
    </div>
  );
}

function Fallback({ data }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.5 }}
      data-testid="reviews-fallback"
      className="mx-auto max-w-2xl rounded-3xl border border-slate-800 bg-brand-card p-8 text-center sm:p-10"
    >
      <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-500/12 text-cyan-300">
        <Info size={26} />
      </span>
      <h3 className="mt-5 font-display text-xl font-bold text-white">Live Google Reviews — awaiting authorization</h3>
      <p className="mt-3 text-sm leading-relaxed text-slate-400" data-testid="reviews-fallback-message">
        {data?.message ||
          "Live review synchronization is awaiting Google Business Profile authorization. Genuine customer reviews are always available directly on Google — use the buttons below. No sample or placeholder reviews are shown here."}
      </p>
      <div className="mt-8 flex justify-center">
        <Buttons />
      </div>
      {data?.oauthConfigured && !data?.connected && (
        <a
          href={`${API}/api/reviews/auth/start`}
          data-testid="reviews-owner-connect-link"
          className="mt-8 inline-flex items-center gap-2 border-t border-white/10 pt-6 text-xs text-slate-500 transition-colors hover:text-cyan-300"
        >
          <RefreshCw size={13} /> Business owner? Connect your Google Business Profile to activate live review sync
        </a>
      )}
    </motion.div>
  );
}

export default function Reviews() {
  const [data, setData] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch(`${API}/api/reviews`)
      .then((r) => r.json())
      .then((d) => !cancelled && (setData(d), setFailed(false)))
      .catch(() => !cancelled && setFailed(true));
    return () => {
      cancelled = true;
    };
  }, []);

  const reviews = data?.reviews || [];
  const summary = data?.summary;
  const hasLive = data && !failed && (data.state === "live" || data.state === "stale") && reviews.length > 0;

  return (
    <section id="reviews" className="relative bg-gradient-to-b from-brand-navy via-brand-navy2 to-brand-navy py-24 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.55 }}
          className="mx-auto max-w-2xl text-center"
        >
          <div className="flex items-center justify-center gap-2.5">
            <GoogleGIcon size={22} />
            <p className="font-mono text-xs uppercase tracking-[0.24em] text-cyan-400">Google Reviews</p>
          </div>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl" data-testid="reviews-heading">
            What customers say <span className="bg-gradient-to-r from-cyan-300 to-emerald-400 bg-clip-text text-transparent">on Google</span>
          </h2>
        </motion.div>

        {failed && <div className="mt-14"><Fallback data={null} /></div>}

        {!data && !failed && (
          <div className="mt-14 grid gap-6 md:grid-cols-3" data-testid="reviews-skeleton">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-48 animate-pulse rounded-3xl border border-slate-800 bg-brand-card" />
            ))}
          </div>
        )}

        {data && !failed && !hasLive && <div className="mt-14"><Fallback data={data} /></div>}

        {hasLive && (
          <>
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.55 }}
              className="mx-auto mt-12 flex max-w-xl flex-col items-center rounded-3xl border border-slate-800 bg-brand-card px-8 py-8 text-center"
              data-testid="reviews-summary-panel"
            >
              <div className="flex items-end gap-3">
                <span className="font-display text-5xl font-extrabold text-white" data-testid="reviews-average-rating">
                  {summary?.averageRating != null ? Number(summary.averageRating).toFixed(1) : "—"}
                </span>
                <span className="pb-1.5 text-slate-500">/ 5</span>
              </div>
              <StarRating rating={summary?.averageRating || 0} size={20} className="mt-3" testId="reviews-summary-stars" />
              <p className="mt-3 text-sm text-slate-400" data-testid="reviews-total-count">
                Based on {summary?.totalReviewCount ?? reviews.length} Google reviews
                {summary?.locationTitle ? ` · ${summary.locationTitle}` : ""}
              </p>
              {data.state === "stale" && (
                <p className="mt-2 text-xs text-slate-500">Cached reviews · sync refreshes automatically every {data.syncIntervalMinutes} minutes</p>
              )}
            </motion.div>

            <div className="mt-12 columns-1 gap-6 md:columns-2 lg:columns-3" data-testid="reviews-list">
              {reviews.map((r) => (
                <ReviewCard key={r.reviewId} review={r} />
              ))}
            </div>

            <div className="mt-10 flex justify-center">
              <Buttons />
            </div>
          </>
        )}
      </div>
    </section>
  );
}
