import { motion } from "framer-motion";
import { Image as ImageIcon } from "lucide-react";
import { GALLERY } from "@/constants/business";

export default function Gallery() {
  return (
    <section id="gallery" className="py-24 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.55 }}
          className="mx-auto max-w-2xl text-center"
        >
          <p className="font-mono text-xs uppercase tracking-[0.24em] text-cyan-400">Gallery</p>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl" data-testid="gallery-heading">
            A look at our <span className="text-emerald-400">service world</span>
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-slate-400" data-testid="gallery-note">
            The visuals below are illustrative placeholders — genuine photographs of the Shravya Services shop and team will replace them as
            they become available.
          </p>
        </motion.div>

        <div className="mt-14 grid grid-cols-2 gap-4 sm:gap-5 lg:grid-cols-3" data-testid="gallery-grid">
          {GALLERY.map((g, i) => (
            <motion.figure
              key={g.src}
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.12 }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.07 }}
              data-testid={`gallery-item-${i}`}
              className="group relative overflow-hidden rounded-3xl border border-slate-800"
            >
              <img
                src={g.src}
                alt={`${g.label} — illustrative visual`}
                loading="lazy"
                className="h-52 w-full object-cover transition-transform duration-500 group-hover:scale-105 sm:h-64"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-navy/90 via-transparent to-transparent" />
              <span className="absolute right-3 top-3 flex items-center gap-1.5 rounded-full bg-brand-navy/70 px-3 py-1 font-mono text-[9px] uppercase tracking-[0.16em] text-slate-300 backdrop-blur" data-testid="gallery-illustrative-badge">
                <ImageIcon size={11} /> Illustrative
              </span>
              <figcaption className="absolute bottom-4 left-4 right-4 text-sm font-medium text-white">{g.label}</figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
