import { useEffect, useState } from "react";
import dayjs from "dayjs";
import { Archive, CheckCheck, Eye, KeyRound, LogOut, MessageCircle, RefreshCw } from "lucide-react";
import Logo from "@/components/Logo";

const API = process.env.REACT_APP_BACKEND_URL;
const KEY_STORAGE = "shravya_admin_key";
const TABS = ["all", "new", "read", "replied", "archived"];

const statusChip = {
  new: "bg-orange-500/20 text-orange-300 border-orange-400/30",
  read: "bg-cyan-500/15 text-cyan-300 border-cyan-400/30",
  replied: "bg-emerald-500/15 text-emerald-300 border-emerald-400/30",
  archived: "bg-slate-500/15 text-slate-400 border-slate-400/20",
};

export default function AdminInbox() {
  const [key, setKey] = useState(() => sessionStorage.getItem(KEY_STORAGE) || "");
  const [authed, setAuthed] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [data, setData] = useState(null);
  const [tab, setTab] = useState("all");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    document.title = "Admin Inbox — Shravya Services";
    const meta = document.createElement("meta");
    meta.name = "robots";
    meta.content = "noindex, nofollow";
    document.head.appendChild(meta);
    return () => {
      document.head.removeChild(meta);
      document.title = "Shravya Services | FASTag, Insurance, GPS Tracking, Taxi & Passport Services in Mangalore";
    };
  }, []);

  const load = async (adminKey, currentTab = tab) => {
    setBusy(true);
    try {
      const q = currentTab === "all" ? "" : `&status=${currentTab}`;
      const r = await fetch(`${API}/api/enquiries?limit=500${q}`, { headers: { "X-Admin-Key": adminKey } });
      if (r.status === 401) {
        setAuthed(false);
        setLoginError("Incorrect admin key. Please try again.");
        sessionStorage.removeItem(KEY_STORAGE);
        return;
      }
      const d = await r.json();
      setData(d);
      setAuthed(true);
      setLoginError("");
      sessionStorage.setItem(KEY_STORAGE, adminKey);
    } catch {
      setLoginError("Could not reach the server. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (key) load(key, "all");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setStatus = async (id, status) => {
    await fetch(`${API}/api/enquiries/${id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", "X-Admin-Key": key },
      body: JSON.stringify({ status }),
    });
    load(key);
  };

  if (!authed) {
    return (
      <div className="flex min-h-screen items-center justify-center px-4">
        <div className="w-full max-w-sm rounded-3xl border border-slate-800 bg-brand-card p-8" data-testid="admin-login-card">
          <Logo />
          <h1 className="mt-7 font-display text-xl font-bold text-white">Admin Inbox</h1>
          <p className="mt-2 text-sm text-slate-400">Enter the admin key to view customer enquiries.</p>
          <div className="mt-6 space-y-4">
            <input
              type="password"
              data-testid="admin-key-input"
              placeholder="Admin key"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && key && load(key, "all")}
              className="w-full rounded-xl border border-slate-700 bg-brand-navy/70 px-4 py-3 text-sm text-white placeholder:text-slate-500 outline-none focus:border-cyan-400/70"
            />
            {loginError && (
              <p className="text-xs text-red-400" data-testid="admin-login-error">
                {loginError}
              </p>
            )}
            <button
              onClick={() => key && load(key, "all")}
              disabled={!key || busy}
              data-testid="admin-login-button"
              className="flex w-full items-center justify-center gap-2 rounded-full bg-emerald-500 px-6 py-3 text-sm font-semibold text-brand-navy transition-colors hover:bg-emerald-400 disabled:opacity-50"
            >
              <KeyRound size={16} /> {busy ? "Checking…" : "Open Inbox"}
            </button>
            <a href="/" data-testid="admin-back-to-site-link" className="block text-center text-xs text-slate-500 hover:text-cyan-300">
              ← Back to website
            </a>
          </div>
        </div>
      </div>
    );
  }

  const filtered = data?.enquiries || [];
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <Logo />
        <div className="flex items-center gap-3">
          <button
            onClick={() => load(key)}
            data-testid="admin-refresh-button"
            className="flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-white/10"
          >
            <RefreshCw size={13} /> Refresh
          </button>
          <button
            onClick={() => {
              sessionStorage.removeItem(KEY_STORAGE);
              setKey("");
              setAuthed(false);
              setData(null);
            }}
            data-testid="admin-logout-button"
            className="flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-white/10"
          >
            <LogOut size={13} /> Log out
          </button>
        </div>
      </div>

      <div className="mt-8 flex flex-wrap items-center gap-2" data-testid="admin-filter-tabs">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => {
              setTab(t);
              load(key, t);
            }}
            data-testid={`admin-filter-${t}`}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold capitalize transition-colors ${
              tab === t ? "bg-cyan-400 text-brand-navy" : "border border-white/15 text-slate-300 hover:bg-white/10"
            }`}
          >
            {t === "all" ? "All" : t} {t === "all" && data ? `(${data.total})` : ""} {t === "new" && data ? `(${data.newCount})` : ""}
          </button>
        ))}
      </div>

      <div className="mt-6 space-y-4" data-testid="admin-enquiry-list">
        {filtered.length === 0 && (
          <div className="rounded-3xl border border-slate-800 bg-brand-card p-10 text-center text-sm text-slate-400" data-testid="admin-empty-state">
            No enquiries in this view yet. New submissions from the website contact form will appear here.
          </div>
        )}
        {filtered.map((enq) => (
          <article key={enq.id} className="rounded-3xl border border-slate-800 bg-brand-card p-6" data-testid="admin-enquiry-card">
            <div className="flex flex-wrap items-center gap-3">
              <span className="font-display text-base font-bold text-white">{enq.name}</span>
              <span className={`rounded-full border px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${statusChip[enq.status] || statusChip.new}`} data-testid="admin-enquiry-status">
                {enq.status}
              </span>
              <span className="rounded-full bg-white/5 px-3 py-0.5 text-xs text-slate-300">{enq.service}</span>
              <span className="ml-auto text-xs text-slate-500">{dayjs(enq.createdAt).format("DD MMM YYYY, hh:mm A")}</span>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-slate-300" data-testid="admin-enquiry-message">
              {enq.message || <span className="text-slate-500">No message provided.</span>}
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2.5">
              <a href={`tel:+91${enq.phone}`} data-testid="admin-enquiry-call-link" className="rounded-full bg-cyan-400/90 px-4 py-1.5 text-xs font-semibold text-brand-navy hover:bg-cyan-300">
                Call {enq.phone}
              </a>
              <a
                href={`https://wa.me/91${enq.phone}?text=${encodeURIComponent(`Hello ${enq.name}, thank you for your enquiry about ${enq.service} at Shravya Services.`)}`}
                target="_blank"
                rel="noopener noreferrer"
                data-testid="admin-enquiry-whatsapp-link"
                className="flex items-center gap-1.5 rounded-full border border-emerald-400/40 bg-emerald-500/10 px-4 py-1.5 text-xs font-semibold text-emerald-300 hover:bg-emerald-500/25"
              >
                <MessageCircle size={12} /> Reply on WhatsApp
              </a>
              {enq.status === "new" && (
                <button onClick={() => setStatus(enq.id, "read")} data-testid="admin-mark-read-button" className="flex items-center gap-1.5 rounded-full border border-white/15 px-4 py-1.5 text-xs font-semibold text-slate-300 hover:bg-white/10">
                  <Eye size={12} /> Mark read
                </button>
              )}
              {enq.status !== "replied" && enq.status !== "archived" && (
                <button onClick={() => setStatus(enq.id, "replied")} data-testid="admin-mark-replied-button" className="flex items-center gap-1.5 rounded-full border border-emerald-400/40 px-4 py-1.5 text-xs font-semibold text-emerald-300 hover:bg-emerald-500/20">
                  <CheckCheck size={12} /> Mark replied
                </button>
              )}
              {enq.status !== "archived" && (
                <button onClick={() => setStatus(enq.id, "archived")} data-testid="admin-archive-button" className="flex items-center gap-1.5 rounded-full border border-white/15 px-4 py-1.5 text-xs font-semibold text-slate-400 hover:bg-white/10">
                  <Archive size={12} /> Archive
                </button>
              )}
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
