import { useEffect, useState } from "react";
import { ArrowUp, Phone } from "lucide-react";
import { BUSINESS, telLink, waLink } from "@/constants/business";
import { WhatsAppIcon } from "@/components/Icons";

export default function FloatingActions() {
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <a
        href={waLink("Hello Shravya Services, I would like to enquire about your services.")}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with Shravya Services on WhatsApp"
        data-testid="floating-whatsapp-button"
        className="animate-pulse-ring fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-[0_8px_30px_rgba(37,211,102,0.45)] transition-transform duration-300 hover:scale-110"
      >
        <WhatsAppIcon size={26} />
      </a>

      <a
        href={telLink(BUSINESS.phones[0])}
        aria-label={`Call Shravya Services at ${BUSINESS.phones[0]}`}
        data-testid="floating-call-button"
        className="fixed bottom-5 left-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-cyan-400 text-brand-navy shadow-[0_8px_30px_rgba(0,229,255,0.4)] transition-transform duration-300 hover:scale-110 md:hidden"
      >
        <Phone size={24} />
      </a>

      {showTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label="Back to top"
          data-testid="back-to-top-button"
          className="fixed bottom-[92px] right-5 z-50 flex h-11 w-11 items-center justify-center rounded-full border border-white/20 bg-brand-navy/80 text-white backdrop-blur transition-all hover:bg-white/15"
        >
          <ArrowUp size={19} />
        </button>
      )}
    </>
  );
}
