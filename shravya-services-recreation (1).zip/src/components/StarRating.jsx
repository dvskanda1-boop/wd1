const StarSvg = ({ size, color }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" className="shrink-0">
    <path
      fill={color}
      d="M12 2.5l2.92 5.92 6.53.95-4.72 4.6 1.11 6.5L12 17.4l-5.84 3.07 1.11-6.5-4.72-4.6 6.53-.95L12 2.5z"
    />
  </svg>
);

const Star = ({ fill, size }) => (
  <span style={{ width: size, height: size }} className="relative inline-block">
    <span className="absolute inset-0">
      <StarSvg size={size} color="#3D4A66" />
    </span>
    <span className="absolute inset-0 overflow-hidden" style={{ width: `${fill * 100}%` }}>
      <StarSvg size={size} color="#FBBF24" />
    </span>
  </span>
);

export default function StarRating({ rating = 0, size = 16, className = "", testId = "star-rating" }) {
  return (
    <div className={`flex items-center gap-0.5 ${className}`} data-testid={testId} aria-label={`Rated ${rating} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} size={size} fill={Math.max(0, Math.min(1, rating - (i - 1)))} />
      ))}
    </div>
  );
}
