import { useState } from "react";
import { motion } from "framer-motion";
import { AlertTriangle, CheckCircle2, Clock, ExternalLink, MapPin, Navigation, Phone, Send, User } from "lucide-react";
import { BUSINESS, HOURS, SERVICES, openStatus, telLink, waLink } from "@/constants/business";
import { WhatsAppIcon } from "@/components/Icons";

const API = process.env.REACT_APP_BACKEND_URL;

const initialForm = { name: "", phone: "", service: "", message: "" };

function HoursTable() {
  const { idx } = openStatus();
  return (
    <div className="rounded-2xl border border-slate-800 bg-brand-card p-6" data-testid="business-hours-card">
      <p className="flex items-center gap-2 font-display text-base font-bold text-white">
        <Clock size={17} className="text-cyan-300" /> Business Hours
      </p>
      <ul className="mt-4 space-y-2">
        {HOURS.map((h, i) => (
          <li
            key={h.day}
            data-testid={`hours-row-${h.day.toLowerCase()}`}
            className={`flex items-center justify-between rounded-lg px-3 py-1.5 text-sm ${i === idx ? "bg-emerald-500/12 font-semibold text-emerald-300" : "text-slate-400"}`}
          >
            <span>{h.day}</span>
            <span className="font-mono text-xs sm:text-sm">
              {h.open} – {h.close}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Contact() {
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(null);
  const [stored, setStored] = useState(null);
  const { open } = openStatus();

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const validate = () => {
    const err = {};
    if (form.name.trim().length < 3) err.name = "Please enter your full name.";
    const phone = form.phone.replace(/\D/g, "").slice(-10);
    if (!/^[6-9]\d{9}$/.test(phone)) err.phone = "Enter a valid 10-digit Indian mobile number.";
    if (!form.service) err.service = "Please choose a service.";
    if (form.message.length > 500) err.message = "Message is too long (max 500 characters).";
    return err;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const err = validate();
    setErrors(err);
    if (Object.keys(err).length > 0) return;
    const phone = form.phone.replace(/\D/g, "").slice(-10);
    const msg = `Hello Shravya Services, I would like to enquire about ${form.service}.\n\nName: ${form.name.trim()}\nPhone: ${phone}\nMessage: ${form.message.trim() || "-"}`;
    const url = waLink(msg);
    try {
      const r = await fetch(`${API}/api/enquiries`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: form.name.trim(), phone, service: form.service, message: form.message.trim() }),
      });
      setStored(r.ok);
    } catch {
      setStored(false);
    }
    window.open(url, "_blank", "noopener,noreferrer");
    setSubmitted(url);
  };

  const field = "w-full rounded-xl border border-slate-700 bg-brand-navy/70 px-4 py-3 text-sm text-white placeholder:text-slate-500 outline-none transition-colors focus:border-cyan-400/70";

  return (
    <section id="contact" className="relative bg-gradient-to-b from-brand-navy via-brand-navy2 to-brand-navy py-24 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.55 }}
          className="mx-auto max-w-2xl text-center"
        >
          <p className="font-mono text-xs uppercase tracking-[0.24em] text-cyan-400">Contact Us</p>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl" data-testid="contact-heading">
            Talk to us — we are <span className="text-orange-400">happy to help</span>
          </h2>
          <p className="mt-4 flex items-center justify-center gap-2 text-sm text-slate-400">
            <User size={15} className="text-orange-400" /> Owner: {BUSINESS.owner}
          </p>
        </motion.div>

        <div className="mt-14 grid gap-8 lg:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.12 }}
            transition={{ duration: 0.55 }}
            className="space-y-6"
          >
            <div className="rounded-3xl border border-slate-800 bg-brand-card p-7" data-testid="contact-info-card">
              <p className="font-display text-lg font-bold text-white">Call or WhatsApp</p>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {BUSINESS.phones.map((p, i) => (
                  <div key={p} className="rounded-2xl border border-slate-700/70 p-4">
                    <a
                      href={telLink(p)}
                      data-testid={`contact-call-button-${i + 1}`}
                      className="flex items-center justify-center gap-2 rounded-full bg-cyan-400/90 px-5 py-2.5 text-sm font-semibold text-brand-navy transition-colors hover:bg-cyan-300"
                    >
                      <Phone size={15} /> Call {p}
                    </a>
                    <a
                      href={waLink(`Hello Shravya Services, I would like to enquire about your services.`)}
                      target="_blank"
                      rel="noopener noreferrer"
                      data-testid={`contact-whatsapp-button-${i + 1}`}
                      className="mt-3 flex items-center justify-center gap-2 rounded-full border border-emerald-400/40 bg-emerald-500/10 px-5 py-2.5 text-sm font-semibold text-emerald-300 transition-colors hover:bg-emerald-500/25"
                    >
                      <WhatsAppIcon size={15} /> WhatsApp
                    </a>
                  </div>
                ))}
              </div>
              <p className="mt-5 flex items-start gap-2 text-sm text-slate-400" data-testid="contact-address">
                <MapPin size={16} className="mt-0.5 shrink-0 text-orange-400" />
                {BUSINESS.location}
                <a
                  href={BUSINESS.directionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid="contact-directions-link"
                  className="ml-1 inline-flex items-center gap-1 font-semibold text-cyan-300 hover:text-cyan-200"
                >
                  <Navigation size={13} /> Directions
                </a>
              </p>
            </div>

            <HoursTable />

            <div className="overflow-hidden rounded-3xl border border-slate-800" data-testid="contact-map-frame">
              <iframe
                title="Shravya Services location map"
                src={BUSINESS.mapEmbedUrl}
                className="h-64 w-full"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.12 }}
            transition={{ duration: 0.55 }}
            className="rounded-3xl border border-slate-800 bg-brand-card p-7 sm:p-9"
            data-testid="enquiry-form-card"
          >
            <h3 className="font-display text-xl font-bold text-white">Send an enquiry</h3>
            <p className="mt-2 text-sm text-slate-400">Fill the form — your enquiry opens directly in WhatsApp so nothing gets lost.</p>

            <form className="mt-7 space-y-5" onSubmit={onSubmit} noValidate data-testid="enquiry-form">
              <div>
                <label htmlFor="enq-name" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Your Name
                </label>
                <input
                  id="enq-name"
                  data-testid="enquiry-name-input"
                  className={field}
                  placeholder="e.g. Ramesh Kumar"
                  value={form.name}
                  onChange={set("name")}
                />
                {errors.name && (
                  <p className="mt-1.5 text-xs text-red-400" data-testid="enquiry-name-error">
                    {errors.name}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="enq-phone" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Phone Number
                </label>
                <input
                  id="enq-phone"
                  data-testid="enquiry-phone-input"
                  className={field}
                  inputMode="numeric"
                  placeholder="10-digit mobile number"
                  value={form.phone}
                  onChange={set("phone")}
                />
                {errors.phone && (
                  <p className="mt-1.5 text-xs text-red-400" data-testid="enquiry-phone-error">
                    {errors.phone}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="enq-service" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Service Required
                </label>
                <select id="enq-service" data-testid="enquiry-service-select" className={`${field} appearance-none`} value={form.service} onChange={set("service")}>
                  <option value="">Select a service…</option>
                  {SERVICES.map((s) => (
                    <option key={s.id} value={s.title}>
                      {s.title}
                    </option>
                  ))}
                </select>
                {errors.service && (
                  <p className="mt-1.5 text-xs text-red-400" data-testid="enquiry-service-error">
                    {errors.service}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="enq-message" className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Message <span className="normal-case text-slate-500">(optional)</span>
                </label>
                <textarea
                  id="enq-message"
                  data-testid="enquiry-message-input"
                  rows={4}
                  className={`${field} resize-none`}
                  placeholder="Tell us what you need help with…"
                  value={form.message}
                  onChange={set("message")}
                />
                {errors.message && (
                  <p className="mt-1.5 text-xs text-red-400" data-testid="enquiry-message-error">
                    {errors.message}
                  </p>
                )}
              </div>

              <button
                type="submit"
                data-testid="enquiry-submit-button"
                className="flex w-full items-center justify-center gap-2.5 rounded-full bg-emerald-500 px-6 py-4 font-semibold text-brand-navy transition-all hover:bg-emerald-400 hover:scale-[1.01]"
              >
                <Send size={17} /> Send Enquiry on WhatsApp
              </button>

              {submitted && (
                <div className="rounded-xl border border-emerald-400/40 bg-emerald-500/10 p-4 text-sm text-emerald-200" data-testid="enquiry-success">
                  <p className="flex items-center gap-2 font-semibold">
                    <CheckCircle2 size={16} /> Enquiry received{stored === true ? " and saved to our system" : ""} — WhatsApp is opening with your details.
                  </p>
                  <p className="mt-1.5 text-xs text-emerald-300/80">
                    Didn&apos;t open?{" "}
                    <a href={submitted} target="_blank" rel="noopener noreferrer" className="underline" data-testid="enquiry-success-link">
                      Tap here to open WhatsApp
                    </a>
                    . We reply during business hours ({open ? "open now" : "see hours"}).
                  </p>
                  {stored === false && (
                    <p className="mt-2 flex items-start gap-1.5 text-xs text-orange-300" data-testid="enquiry-storage-warning">
                      <AlertTriangle size={13} className="mt-0.5 shrink-0" /> Your enquiry could not be logged in our system just now — please make sure to send the WhatsApp message so we don&apos;t miss it.
                    </p>
                  )}
                </div>
              )}
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
