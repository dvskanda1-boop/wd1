import { motion } from "framer-motion";
import { CheckCircle2, Headphones, MessageCircle, Phone, Store } from "lucide-react";
import { BUSINESS, IMAGES } from "@/constants/business";

const POINTS = [
  { icon: Store, text: "Multiple services under one roof — from FASTag to passport assistance." },
  { icon: Headphones, text: "Convenient customer support for every service enquiry." },
  { icon: MessageCircle, text: "Easy enquiry through phone and WhatsApp." },
  { icon: CheckCircle2, text: "Commitment to customer satisfaction on every visit." },
];

export default function About() {
  return (
    <section id="about" className="relative py-24 sm:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2 lg:gap-20 lg:px-8">
        <motion.div
          initial={{ opacity: 0, x: -28 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.15 }}
          transition={{ duration: 0.6 }}
        >
          <p className="font-mono text-xs uppercase tracking-[0.24em] text-cyan-400">About Us</p>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl" data-testid="about-heading">
            A customer-focused service point in <span className="text-emerald-400">Mangalore</span>
          </h2>
          <p className="mt-5 leading-relaxed text-slate-300" data-testid="about-paragraph">
            {BUSINESS.name}, operated by {BUSINESS.owner}, brings together everyday vehicle and travel services in one convenient location
            near the Kia Showroom at Mallikatta. From FASTag support to taxi enquiries, our team is ready to help you with a simple, honest
            and quick enquiry process.
          </p>
          <ul className="mt-8 space-y-4">
            {POINTS.map((p) => (
              <li key={p.text} className="flex items-start gap-3" data-testid="about-point-item">
                <span className="mt-0.5 rounded-lg bg-emerald-500/15 p-2 text-emerald-400">
                  <p.icon size={17} />
                </span>
                <span className="text-sm leading-relaxed text-slate-300 sm:text-base">{p.text}</span>
              </li>
            ))}
          </ul>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 28 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.15 }}
          transition={{ duration: 0.6 }}
          className="relative"
        >
          <div className="overflow-hidden rounded-3xl border border-white/10 shadow-glow">
            <img src={IMAGES.about} alt="Driving experience visual" className="h-[420px] w-full object-cover" loading="lazy" />
          </div>
          <div className="animate-floaty absolute -bottom-6 left-6 rounded-2xl border border-white/10 bg-brand-card/90 px-6 py-4 shadow-glow backdrop-blur-xl" data-testid="about-owner-card">
            <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-cyan-300">Managed by</p>
            <p className="mt-1 font-display text-lg font-bold text-white">{BUSINESS.owner}</p>
            <p className="text-xs text-slate-400">Proprietor, {BUSINESS.name}</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
