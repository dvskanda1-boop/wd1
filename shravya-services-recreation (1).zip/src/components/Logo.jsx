export default function Logo({ large = false, sub = "FASTAG TAG SERVICE" }) {
  const s = large ? 56 : 42;
  return (
    <div className="flex items-center gap-3">
      <svg width={s} height={s} viewBox="0 0 48 48" role="img" aria-label="Shravya Services logo" data-testid="brand-logo">
        <defs>
          <linearGradient id="shravyaTag" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#10B981" />
            <stop offset="1" stopColor="#059669" />
          </linearGradient>
        </defs>
        <rect x="3" y="3" width="42" height="42" rx="13" fill="url(#shravyaTag)" />
        <circle cx="36.5" cy="11.5" r="2.6" fill="#0A1128" opacity="0.5" />
        <path d="M14 33.5 L23.5 14.5 M20.5 33.5 L30 14.5" stroke="#fff" strokeWidth="3.4" strokeLinecap="round" fill="none" />
      </svg>
      <div className="leading-none">
        <div className={`font-display font-extrabold tracking-tight text-white ${large ? "text-2xl" : "text-lg"}`}>SHRAVYA</div>
        <div className={`font-mono tracking-[0.26em] text-cyan-300 ${large ? "text-[10px] mt-1.5" : "text-[8px] mt-1"}`}>{sub}</div>
      </div>
    </div>
  );
}
