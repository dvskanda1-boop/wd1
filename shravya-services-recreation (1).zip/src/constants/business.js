export const BUSINESS = {
  name: "Shravya Services",
  brand: "Shravya FASTag Tag Service",
  owner: "SHANTHALINGESH.B.V",
  phones: ["9972194799", "9964587637"],
  whatsapp: "919972194799",
  whatsappDisplay: "+91 99721 94799",
  location: "Near Kia Showroom, Mallikatta, Mangalore, Karnataka",
  mapsUrl:
    "https://www.google.co.in/maps/place/Shravya+Fastag+tag+service+with+Updation+of+HSRP+number+plate+and+Taxi+services+at+mlore/@12.8235887,75.2235538,10z/data=!4m8!3m7!1s0x3ba35b8af246a89b:0xbd5b030ea7fe22bf!8m2!3d12.8235887!4d75.2235538!9m1!1b1!16s%2Fg%2F11q1qx5t5c",
  geo: { lat: 12.8891667, lng: 74.8469444 },
  directionsUrl: "https://www.google.com/maps/dir/?api=1&destination=12.8891667%2C74.8469444",
  mapEmbedUrl: "https://www.google.com/maps?q=12.8891667%2C74.8469444&z=16&output=embed",
};

export const HOURS = [
  { day: "Monday", open: "9:00 AM", close: "9:00 PM", o: [9, 0], c: [21, 0] },
  { day: "Tuesday", open: "9:00 AM", close: "9:00 PM", o: [9, 0], c: [21, 0] },
  { day: "Wednesday", open: "9:00 AM", close: "9:00 PM", o: [9, 0], c: [21, 0] },
  { day: "Thursday", open: "9:00 AM", close: "9:00 PM", o: [9, 0], c: [21, 0] },
  { day: "Friday", open: "9:00 AM", close: "9:00 PM", o: [9, 0], c: [21, 0] },
  { day: "Saturday", open: "9:00 AM", close: "9:00 PM", o: [9, 0], c: [21, 0] },
  { day: "Sunday", open: "10:30 AM", close: "3:00 PM", o: [10, 30], c: [15, 0] },
];

const U = (id, w = 1200) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=80`;

export const IMAGES = {
  hero: U("photo-1782754521601-19691d69c25f", 2000),
  about: U("photo-1620584899131-a5ff5f8fbb03"),
};

export const SERVICES = [
  {
    id: "fastag",
    title: "FASTag Services",
    primary: true,
    tagline: "Our Primary Service",
    image: U("photo-1758939858341-24214bae571b"),
    description:
      "FASTag-related customer services — new tag enquiries, recharge support, replacement and issue resolution, along with HSRP number plate update assistance.",
    features: ["New FASTag enquiries", "Recharge & replacement support", "Issue resolution assistance", "HSRP number plate updates"],
    msg: "Hello Shravya Services, I need help with FASTag services.",
  },
  {
    id: "insurance",
    title: "Health & Vehicle Insurance",
    image: U("photo-1732408433038-73d2f6741fc5"),
    description: "Health insurance and vehicle insurance enquiries — clear guidance and support to choose the right coverage.",
    features: ["Health insurance enquiries", "Vehicle insurance enquiries", "Renewal guidance", "Claim support assistance"],
    msg: "Hello Shravya Services, I am interested in vehicle insurance.",
  },
  {
    id: "gps",
    title: "GPS Tracker & Panic Button",
    image: U("photo-1634743556192-d19f0c69ff3a"),
    description: "GPS tracking solutions and panic button installation enquiries for private and commercial vehicles.",
    features: ["GPS tracking solutions", "Panic button installation enquiries", "Live location support", "Commercial & private vehicles"],
    msg: "Hello Shravya Services, I need GPS tracker installation.",
  },
  {
    id: "taxi",
    title: "Taxi Services",
    image: U("photo-1624607391672-2b7d1bcafe7c"),
    description: "Taxi booking enquiries — contact us for your travel requirements in and around Mangalore.",
    features: ["Local & outstation travel", "Airport transfer enquiries", "Booking by call or WhatsApp", "Contact for travel requirements"],
    msg: "Hello Shravya Services, I would like to enquire about taxi services.",
  },
  {
    id: "passport",
    title: "Passport Services",
    image: U("photo-1581553673739-c4906b5d0de8"),
    description: "Passport-related service enquiries — contact us for assistance with your application and documentation.",
    features: ["Application assistance", "Renewal enquiries", "Documentation guidance", "Contact for support"],
    msg: "Hello Shravya Services, I need assistance with passport services.",
  },
];

export const GALLERY = [
  { src: U("photo-1708805282683-50a060eba80f"), label: "Vehicle care in progress" },
  { src: U("photo-1603638725135-928baf863eff"), label: "GPS & navigation support" },
  { src: U("photo-1628000726658-81c8beb93d46"), label: "Taxi service on duty" },
  { src: U("photo-1618934116136-16d28f184b10"), label: "Vehicle exterior care" },
  { src: U("photo-1585014165903-6d6c6ebad3e9"), label: "Dashboard & electronics" },
  { src: U("photo-1554224155-cfa08c2a758f"), label: "Service desk assistance" },
];

export const waLink = (msg) => `https://wa.me/${BUSINESS.whatsapp}?text=${encodeURIComponent(msg)}`;
export const telLink = (phone) => `tel:+91${phone}`;

export function openStatus() {
  const now = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));
  const idx = (now.getDay() + 6) % 7;
  const today = HOURS[idx];
  const mins = now.getHours() * 60 + now.getMinutes();
  const open = mins >= today.o[0] * 60 + today.o[1] && mins < today.c[0] * 60 + today.c[1];
  return { idx, today, open };
}
