import "@/App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Services from "@/components/Services";
import WhyChooseUs from "@/components/WhyChooseUs";
import Reviews from "@/components/Reviews";
import Gallery from "@/components/Gallery";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import FloatingActions from "@/components/FloatingActions";
import AdminInbox from "@/components/AdminInbox";
import ErrorBoundary from "@/components/ErrorBoundary";

function Site() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <About />
        <Services />
        <WhyChooseUs />
        <Reviews />
        <Gallery />
        <Contact />
      </main>
      <Footer />
      <FloatingActions />
    </>
  );
}

function App() {
  return (
    <div className="min-h-screen bg-brand-navy font-body text-white antialiased">
      <ErrorBoundary>
        <BrowserRouter>
          <Routes>
            <Route path="/admin" element={<AdminInbox />} />
            <Route path="*" element={<Site />} />
          </Routes>
        </BrowserRouter>
      </ErrorBoundary>
    </div>
  );
}

export default App;
