module.exports = {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  corePlugins: {
    preflight: false,
  },
  theme: {
    extend: {
      colors: {
        brand: {
          navy: "#0A1128",
          navy2: "#0F1C3F",
          card: "#14213D",
        },
      },
      fontFamily: {
        display: ["Outfit", "sans-serif"],
        body: ["Plus Jakarta Sans", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
      boxShadow: {
        glow: "0 0 40px rgba(0, 229, 255, 0.18)",
        glowGreen: "0 0 45px rgba(16, 185, 129, 0.25)",
      },
      borderColor: {
        border: "hsl(var(--border))",
      },
    },
  },
  plugins: [],
};
