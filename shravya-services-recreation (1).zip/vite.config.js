import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";
import { fileURLToPath } from "node:url";

const rootDir = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(rootDir, "src"),
    },
  },
  define: {
    "process.env.REACT_APP_BACKEND_URL": JSON.stringify(""),
  },
  server: {
    host: "0.0.0.0",
    port: 3000,
    strictPort: true,
  },
});
